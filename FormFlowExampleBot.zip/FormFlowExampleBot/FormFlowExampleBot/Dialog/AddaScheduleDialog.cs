﻿using FormFlowExampleBot.Form;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Schema;
using Newtonsoft.Json;
using NodaTime;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace FormFlowExampleBot.Dialog
{
    public class AddaScheduleDialog : WaterfallDialog
    {
        private string cards = @"./AdaptiveCard.json";
        public AddaScheduleDialog(string dialogId, IEnumerable<WaterfallStep> steps = null)
           : base(dialogId, steps)
        {

            AddStep(async (stepContext, cancellationToken) =>
            {

                //var state = await (stepContext.Context.TurnState["FormFlowExampleBotAccessors"] as FormFlowExampleBotAccessors).CounterStateStateAccessor.GetAsync(stepContext.Context);
                var cardAttachment = CreateAdaptiveCardAttachment(this.cards);
                var reply = stepContext.Context.Activity.CreateReply();
                reply.Attachments = new List<Attachment>() { cardAttachment };

                await stepContext.Context.SendActivityAsync(reply, cancellationToken: cancellationToken);

                var opts = new PromptOptions
                {
                    Prompt = new Activity
                    {
                        Type = ActivityTypes.Message,
                        Text = "waiting for user input...", // You can comment this out if you don't want to display any text. Still works.
                    },
                };
                return await stepContext.PromptAsync(nameof(TextPrompt), opts);

            });

            AddStep(async (stepContext, cancellationToken) =>
            {

                //var state = await (stepContext.Context.TurnState["FormFlowExampleBotAccessors"] as FormFlowExampleBotAccessors).CounterStateStateAccessor.GetAsync(stepContext.Context);
                await stepContext.Context.SendActivityAsync($"INPUT: {stepContext.Result}");
                AddScheduleForm.CurentShceduleDate = stepContext.Result.ToString();

                return await stepContext.NextAsync();

            });

            AddStep(async (stepContext, cancellationToken) =>
            {

                    return await stepContext.EndDialogAsync();
                
            });
        }

        public static new string Id => "AddaScheduleDialog";

        public static AddaScheduleDialog Instance { get; } = new AddaScheduleDialog(Id);

        private static Attachment CreateAdaptiveCardAttachment(string filePath)
        {
            var adaptiveCardJson = File.ReadAllText(filePath);
            var adaptiveCardAttachment = new Attachment()
            {
                ContentType = "application/vnd.microsoft.card.adaptive",
                Content = JsonConvert.DeserializeObject(adaptiveCardJson),
            };
            return adaptiveCardAttachment;
        }
    }
}
