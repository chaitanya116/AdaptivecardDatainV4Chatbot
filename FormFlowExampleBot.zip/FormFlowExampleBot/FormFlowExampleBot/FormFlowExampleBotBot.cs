﻿// Copyright (c) Microsoft Corporation. All rights reserved.
// Licensed under the MIT License.

using System.Threading;
using System.Threading.Tasks;
using Bot.Builder.Community.Dialogs.FormFlow;
using FormFlowExampleBot.Dialog;
using FormFlowExampleBot.Form;
using Microsoft.Bot.Builder;
using Microsoft.Bot.Builder.Dialogs;
using Microsoft.Bot.Schema;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json.Linq;

namespace FormFlowExampleBot
{
    /// <summary>
    /// Represents a bot that processes incoming activities.
    /// For each user interaction, an instance of this class is created and the OnTurnAsync method is called.
    /// This is a Transient lifetime service.  Transient lifetime services are created
    /// each time they're requested. For each Activity received, a new instance of this
    /// class is created. Objects that are expensive to construct, or have a lifetime
    /// beyond the single turn, should be carefully managed.
    /// For example, the <see cref="MemoryStorage"/> object and associated
    /// <see cref="IStatePropertyAccessor{T}"/> object are created with a singleton lifetime.
    /// </summary>
    /// <seealso cref="https://docs.microsoft.com/en-us/aspnet/core/fundamentals/dependency-injection?view=aspnetcore-2.1"/>
    public class FormFlowExampleBotBot : IBot
    {
        private readonly DialogSet dialogs;
        public const string ConnectionName = "OAuthConnection";
        public const string LoginPromptName = "loginPrompt";

        /// <summary>
        /// Initializes a new instance of the class.
        /// </summary>
        /// <param name="conversationState">The managed conversation state.</param>
        /// <param name="loggerFactory">A <see cref="ILoggerFactory"/> that is hooked to the Azure App Service provider.</param>
        /// <seealso cref="https://docs.microsoft.com/en-us/aspnet/core/fundamentals/logging/?view=aspnetcore-2.1#windows-eventlog-provider"/>
        public FormFlowExampleBotBot(FormFlowExampleBotAccessors botAccessors, ILoggerFactory loggerFactory)
        {
            var dialogState = botAccessors.DialogStateAccessor;

            // compose dialogs
            dialogs = new DialogSet(dialogState);
            // dialogs.Add(Prompt(ConnectionName));

            dialogs.Add(AddaScheduleDialog.Instance);
            FormFlowExampleBotAccessors = botAccessors;
        }

        public FormFlowExampleBotAccessors FormFlowExampleBotAccessors { get; }

        /// <summary>
        /// Every conversation turn for our Echo Bot will call this method.
        /// There are no dialogs used, since it's "single turn" processing, meaning a single
        /// request and response.
        /// </summary>
        /// <param name="turnContext">A <see cref="ITurnContext"/> containing all the data needed
        /// for processing this conversation turn. </param>
        /// <param name="cancellationToken">(Optional) A <see cref="CancellationToken"/> that can be used by other objects
        /// or threads to receive notice of cancellation.</param>
        /// <returns>A <see cref="Task"/> that represents the work queued to execute.</returns>
        /// <seealso cref="BotStateSet"/>
        /// <seealso cref="ConversationState"/>
        /// <seealso cref="IMiddleware"/>
        public async Task OnTurnAsync(ITurnContext turnContext, CancellationToken cancellationToken = default(CancellationToken))
        {
            // Handle Message activity type, which is the main activity type for shown within a conversational interface
            // Message activities may contain text, speech, interactive cards, and binary or unknown attachments.
            // see https://aka.ms/about-bot-activity-message to learn more about the message and other activity types
            if (turnContext.Activity.Type == ActivityTypes.Message)
            {
                // Get the conversation state from the turn context.
                var state = await FormFlowExampleBotAccessors.CounterStateStateAccessor.GetAsync(turnContext, () => new CounterState(), cancellationToken);

                turnContext.TurnState.Add("BotAccessors", FormFlowExampleBotAccessors);


                var dialogCtx = await dialogs.CreateContextAsync(turnContext, cancellationToken);

                if (dialogCtx.Context.Activity.GetType().GetProperty("ChannelData") != null)
                {
                    var channelData = JObject.Parse(dialogCtx.Context.Activity.ChannelData.ToString());
                    if (channelData.ContainsKey("postBack"))
                    {
                        var postbackActivity = dialogCtx.Context.Activity;
                        // Convert the user's Adaptive Card input into the input of a Text Prompt
                        // Must be sent as a string
                        postbackActivity.Text = postbackActivity.Value.ToString();
                        await dialogCtx.Context.SendActivityAsync(postbackActivity);
                    }
                }

                if (dialogCtx.ActiveDialog == null)
                {
                    await dialogCtx.BeginDialogAsync(AddaScheduleDialog.Id, cancellationToken);
                }
                else
                {
                    await dialogCtx.ContinueDialogAsync(cancellationToken);
                }

                await FormFlowExampleBotAccessors.ConversationState.SaveChangesAsync(turnContext, false, cancellationToken);
            }           
            
        }

        public  static OAuthPrompt Prompt(string connectionName)
        {
            return new OAuthPrompt(
               LoginPromptName,
               new OAuthPromptSettings
               {
                   ConnectionName = connectionName,
                   Text = "Please Sign In : ",
                   Title = "Sign In",
                   Timeout = 300000, // User has 5 minutes to login (1000 * 60 * 5)
               });
        }

    }
}
