﻿using Bot.Builder.Community.Dialogs.FormFlow;
using Microsoft.Bot.Schema;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FormFlowExampleBot.Form
{
    [Serializable]
    public static class AddScheduleForm
    {
        public static string VMName { get; set; }

        public static string ResourceGroupName { get; set; }

        public static string SubscriptionID { get; set; }

        public static DateTime ScheduleDate { get; set; }

        public static DateTime StartTime { get; set; }

        public static DateTime StopTime { get; set; }

        public static string VMchange { get; set; }
        public static string CurentShceduleDate { get; set; }

        public static string CurentStartorStopTime { get; set; }

        public static TokenResponse TokenResponse { get; set; }

    }
}
